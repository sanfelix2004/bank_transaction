package com.example.rubrica.mapper;

import com.example.rubrica.dto.AccountDTO;
import com.example.rubrica.entity.Account;

public class AccountMapper {

    public static AccountDTO toDTO(Account account) {
        return new AccountDTO(account.getId(), account.getUserId(), account.getBalance());
    }

    public static Account toEntity(AccountDTO accountDTO) {
        return new Account(accountDTO.getId(), accountDTO.getUserId(), accountDTO.getBalance());
    }
}
