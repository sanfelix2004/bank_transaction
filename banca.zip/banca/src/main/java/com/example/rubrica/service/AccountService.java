package com.example.rubrica.service;

import com.example.rubrica.dto.AccountDTO;
import com.example.rubrica.entity.Account;
import com.example.rubrica.mapper.AccountMapper;
import com.example.rubrica.repository.AccountRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.stream.Collectors;

@Service
public class AccountService {

    private final AccountRepository accountRepository;

    public AccountService(AccountRepository accountRepository) {
        this.accountRepository = accountRepository;
    }

    public void createAccount(String userId, double initialBalance) {
        String accountId = userId + "-account";
        Account account = new Account(accountId, userId, initialBalance);
        accountRepository.save(account);
    }

    public AccountDTO getAccountByUserId(String userId) throws ExecutionException, InterruptedException {
        Account account = accountRepository.findByUserId(userId);
        if (account == null) {
            throw new IllegalStateException("Account non trovato per l'utente con ID " + userId);
        }
        return AccountMapper.toDTO(account);
    }

    public List<AccountDTO> getAllAccounts() throws ExecutionException, InterruptedException {
        List<Account> accounts = accountRepository.getAllAccounts();
        return accounts.stream()
                .map(AccountMapper::toDTO)
                .collect(Collectors.toList());
    }
}
