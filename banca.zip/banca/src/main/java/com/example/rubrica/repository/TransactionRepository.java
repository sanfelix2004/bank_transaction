package com.example.rubrica.repository;

import com.example.rubrica.entity.Transaction;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import org.springframework.stereotype.Repository;

import java.util.concurrent.ExecutionException;

@Repository
public class TransactionRepository {

    private final Firestore firestore;

    public TransactionRepository(Firestore firestore) {
        this.firestore = firestore;
    }

    public void save(Transaction transaction) {
        firestore.collection("transactions").document(transaction.getId()).set(transaction);
    }

    public Transaction findById(String transactionId) throws ExecutionException, InterruptedException {
        DocumentReference document = firestore.collection("transactions").document(transactionId);
        return document.get().get().toObject(Transaction.class);
    }
}
