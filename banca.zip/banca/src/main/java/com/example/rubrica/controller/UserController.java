package com.example.rubrica.controller;

import com.example.rubrica.dto.UserDTO;
import com.example.rubrica.delegate.UserDelegate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/users")
@Tag(name = "Users", description = "Gestione degli utenti")
public class UserController {

    private final UserDelegate userDelegate;

    public UserController(UserDelegate userDelegate) {
        this.userDelegate = userDelegate;
    }

    @PostMapping
    @Operation(summary = "Crea un nuovo utente", description = "Endpoint per creare un nuovo utente")
    public ResponseEntity<String> createUser(@RequestBody UserDTO userDTO) {
        return ResponseEntity.ok(userDelegate.createUser(userDTO));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Recupera un utente", description = "Endpoint per recuperare un utente tramite ID")
    public ResponseEntity<UserDTO> getUserById(@PathVariable String id) throws ExecutionException, InterruptedException {
        return ResponseEntity.ok(userDelegate.getUserById(id));
    }
}
