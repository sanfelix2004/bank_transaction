package com.example.rubrica.controller;

import com.example.rubrica.dto.TransactionDTO;
import com.example.rubrica.delegate.TransactionDelegate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/transactions")
public class TransactionController {

    private final TransactionDelegate transactionDelegate;

    public TransactionController(TransactionDelegate transactionDelegate) {
        this.transactionDelegate = transactionDelegate;
    }

    @PostMapping("/transfer")
    public ResponseEntity<String> transferMoney(
            @RequestParam String fromAccountId,
            @RequestParam String toAccountId,
            @RequestParam double amount) {
        try {
            transactionDelegate.transferMoney(fromAccountId, toAccountId, amount);
            return ResponseEntity.ok("Transfer completed successfully.");
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error during transfer: " + e.getMessage());
        }
    }

    @GetMapping("/{transactionId}")
    public ResponseEntity<TransactionDTO> getTransactionById(@PathVariable String transactionId) {
        try {
            TransactionDTO transaction = transactionDelegate.getTransactionById(transactionId);
            return ResponseEntity.ok(transaction);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }
}
