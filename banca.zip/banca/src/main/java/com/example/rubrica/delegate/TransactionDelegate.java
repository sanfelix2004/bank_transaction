package com.example.rubrica.delegate;

import com.example.rubrica.dto.TransactionDTO;
import com.example.rubrica.service.TransactionService;
import org.springframework.stereotype.Component;

@Component
public class TransactionDelegate {

    private final TransactionService transactionService;

    public TransactionDelegate(TransactionService transactionService) {
        this.transactionService = transactionService;
    }

    public void transferMoney(String fromAccountId, String toAccountId, double amount) throws Exception {
        transactionService.transferMoney(fromAccountId, toAccountId, amount);
    }

    public TransactionDTO getTransactionById(String transactionId) throws Exception {
        return transactionService.getTransactionById(transactionId);
    }
}
