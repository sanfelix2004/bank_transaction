package com.example.rubrica.controller;

import com.example.rubrica.dto.AccountDTO;
import com.example.rubrica.delegate.AccountDelegate;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping("/accounts")
public class AccountController {

    private final AccountDelegate accountDelegate;

    public AccountController(AccountDelegate accountDelegate) {
        this.accountDelegate = accountDelegate;
    }

    @PostMapping("/{userId}")
    public ResponseEntity<String> createAccount(@PathVariable String userId, @RequestParam double initialBalance) {
        accountDelegate.createAccount(userId, initialBalance);
        return ResponseEntity.ok("Account created successfully for user " + userId);
    }

    @GetMapping("/{userId}")
    public ResponseEntity<AccountDTO> getAccountByUserId(@PathVariable String userId) throws ExecutionException, InterruptedException {
        AccountDTO account = accountDelegate.getAccountByUserId(userId);
        if (account == null) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok(account);
    }

    @GetMapping
    public ResponseEntity<List<AccountDTO>> getAllAccounts() throws ExecutionException, InterruptedException {
        List<AccountDTO> accounts = accountDelegate.getAllAccounts();
        return ResponseEntity.ok(accounts);
    }


}
