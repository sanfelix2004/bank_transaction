package com.example.rubrica.repository;

import com.example.rubrica.entity.Account;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.Firestore;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.concurrent.ExecutionException;

@Repository
public class AccountRepository {

    private final Firestore firestore;

    public AccountRepository(Firestore firestore) {
        this.firestore = firestore;
    }

    public void save(Account account) {
        CollectionReference accountsCollection = firestore.collection("accounts");
        accountsCollection.document(account.getId()).set(account);
    }

    public Account findByUserId(String userId) throws ExecutionException, InterruptedException {
        CollectionReference accountsCollection = firestore.collection("accounts");
        var querySnapshot = accountsCollection.whereEqualTo("userId", userId).get().get();

        if (querySnapshot.isEmpty()) {
            System.err.println("Nessun account trovato per userId: " + userId);
            return null;
        }

        return querySnapshot.toObjects(Account.class).stream().findFirst().orElse(null);
    }

    public List<Account> getAllAccounts() throws ExecutionException, InterruptedException {
        CollectionReference accountsCollection = firestore.collection("accounts");
        var querySnapshot = accountsCollection.get().get();

        if (querySnapshot.isEmpty()) {
            System.out.println("Nessun account trovato nella collezione.");
            return List.of();
        }

        return querySnapshot.toObjects(Account.class);
    }
}
