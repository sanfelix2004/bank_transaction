package com.example.rubrica.service;

import com.example.rubrica.dto.TransactionDTO;
import com.example.rubrica.entity.Account;
import com.example.rubrica.entity.Transaction;
import com.example.rubrica.mapper.TransactionMapper;
import com.example.rubrica.repository.AccountRepository;
import com.example.rubrica.repository.TransactionRepository;
import com.google.cloud.firestore.Firestore;
import com.google.cloud.firestore.Transaction.Function;
import org.springframework.stereotype.Service;

import java.util.UUID;

@Service
public class TransactionService {

    private final Firestore firestore;
    private final AccountRepository accountRepository;
    private final TransactionRepository transactionRepository;

    public TransactionService(Firestore firestore, AccountRepository accountRepository, TransactionRepository transactionRepository) {
        this.firestore = firestore;
        this.accountRepository = accountRepository;
        this.transactionRepository = transactionRepository;
    }

    public void transferMoney(String fromUserId, String toUserId, double amount) throws Exception {
        if (amount <= 0) {
            throw new IllegalArgumentException("Amount must be greater than zero.");
        }

        firestore.runTransaction((Function<Void>) transaction -> {
            Account fromAccount = accountRepository.findByUserId(fromUserId);
            if (fromAccount == null || fromAccount.getBalance() < amount) {
                throw new IllegalStateException("Saldo insufficiente o account di origine non trovato.");
            }

            Account toAccount = accountRepository.findByUserId(toUserId);
            if (toAccount == null) {
                throw new IllegalStateException("L'account di destinazione non esiste.");
            }

            fromAccount.setBalance(fromAccount.getBalance() - amount);
            toAccount.setBalance(toAccount.getBalance() + amount);

            transaction.set(firestore.collection("accounts").document(fromAccount.getId()), fromAccount);
            transaction.set(firestore.collection("accounts").document(toAccount.getId()), toAccount);

            Transaction txn = new Transaction(
                    UUID.randomUUID().toString(),
                    fromAccount.getId(),
                    toAccount.getId(),
                    amount,
                    java.time.Instant.now().toString()
            );
            transaction.set(firestore.collection("transactions").document(txn.getId()), txn);

            return null;
        }).get();
    }

    public TransactionDTO getTransactionById(String transactionId) throws Exception {
        Transaction transaction = transactionRepository.findById(transactionId);
        return transaction != null ? TransactionMapper.toDTO(transaction) : null;
    }
}
