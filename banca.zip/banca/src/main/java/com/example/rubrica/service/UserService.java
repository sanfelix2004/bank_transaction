package com.example.rubrica.service;

import com.example.rubrica.dto.UserDTO;
import com.example.rubrica.entity.User;
import com.example.rubrica.exception.UserNotFoundException;
import com.example.rubrica.mapper.UserMapper;
import com.example.rubrica.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.util.concurrent.ExecutionException;

@Service
public class UserService {

    private final UserRepository userRepository;

    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public String createUser(UserDTO userDTO) {
        User user = UserMapper.toEntity(userDTO);
        userRepository.save(user);
        return "User created successfully!";
    }

    public UserDTO getUserById(String id) throws ExecutionException, InterruptedException {
        User user = userRepository.findById(id);
        if (user == null) {
            throw new UserNotFoundException("User with ID " + id + " not found.");
        }
        return UserMapper.toDTO(user);
    }
}
