package com.example.rubrica.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class OpenApiController {

    @GetMapping(value = "/v3/api-docs.yaml", produces = "application/yaml")
    public String getYamlDocs() {
        return new RestTemplate().getForObject("http://localhost:8080/v3/api-docs", String.class);
    }
}
