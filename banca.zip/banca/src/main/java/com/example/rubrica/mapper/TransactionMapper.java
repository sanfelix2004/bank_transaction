package com.example.rubrica.mapper;

import com.example.rubrica.dto.TransactionDTO;
import com.example.rubrica.entity.Transaction;

public class TransactionMapper {

    public static TransactionDTO toDTO(Transaction transaction) {
        return new TransactionDTO(
                transaction.getId(),
                transaction.getFromAccountId(),
                transaction.getToAccountId(),
                transaction.getAmount(),
                transaction.getTimestamp()
        );
    }

    public static Transaction toEntity(TransactionDTO transactionDTO) {
        return new Transaction(
                transactionDTO.getId(),
                transactionDTO.getFromAccountId(),
                transactionDTO.getToAccountId(),
                transactionDTO.getAmount(),
                transactionDTO.getTimestamp()
        );
    }
}
