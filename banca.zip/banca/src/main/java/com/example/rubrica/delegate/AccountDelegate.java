package com.example.rubrica.delegate;

import com.example.rubrica.dto.AccountDTO;
import com.example.rubrica.service.AccountService;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.ExecutionException;

@Component
public class AccountDelegate {

    private final AccountService accountService;

    public AccountDelegate(AccountService accountService) {
        this.accountService = accountService;
    }

    public void createAccount(String userId, double initialBalance) {
        accountService.createAccount(userId, initialBalance);
    }

    public AccountDTO getAccountByUserId(String userId) throws ExecutionException, InterruptedException {
        return accountService.getAccountByUserId(userId);
    }

    public List<AccountDTO> getAllAccounts() throws ExecutionException, InterruptedException {
        return accountService.getAllAccounts();
    }
}
