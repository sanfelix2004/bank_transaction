package com.example.rubrica.repository;

import com.example.rubrica.entity.User;
import com.google.cloud.firestore.CollectionReference;
import com.google.cloud.firestore.DocumentReference;
import com.google.cloud.firestore.Firestore;
import org.springframework.stereotype.Repository;

import java.util.concurrent.ExecutionException;

@Repository
public class UserRepository {

    private final Firestore firestore;

    public UserRepository(Firestore firestore) {
        this.firestore = firestore;
    }

    public void save(User user) {
        CollectionReference usersCollection = firestore.collection("users");
        usersCollection.document(user.getId()).set(user);
    }

    public User findById(String id) throws ExecutionException, InterruptedException {
        DocumentReference document = firestore.collection("users").document(id);
        return document.get().get().toObject(User.class);
    }
}
