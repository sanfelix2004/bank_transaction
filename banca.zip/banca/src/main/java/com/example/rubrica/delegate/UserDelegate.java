package com.example.rubrica.delegate;

import com.example.rubrica.dto.UserDTO;
import com.example.rubrica.service.UserService;
import org.springframework.stereotype.Component;

import java.util.concurrent.ExecutionException;

@Component
public class UserDelegate {

    private final UserService userService;

    public UserDelegate(UserService userService) {
        this.userService = userService;
    }

    public String createUser(UserDTO userDTO) {
        return userService.createUser(userDTO);
    }

    public UserDTO getUserById(String id) throws ExecutionException, InterruptedException {
        return userService.getUserById(id);
    }
}
